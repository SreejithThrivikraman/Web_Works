<?php

include_once 'database.php';

$flag_1 = $_GET["flag_input_1"];
$flag_2 = $_POST["flag_input_2"];
$input_data = "abc";
$input_nonce = rand();


$combinedData = $input_data .$input_nonce  ;
$output = hash ( "sha256" , $combinedData );


echo $flag_1."  ".$flag_2;

if ($flag_1 === "start")
 {
  // code...
  $status = "Completed";
//  echo "The entry data is: ".$input_data.$input_nonce;
    echo "<h1>Server Started !</h1>";
   $query_insert =
    'INSERT INTO blocks (hashcode, nonce, status) ' .
    'VALUES ("' .$output  . '","' . $input_nonce  . '","' . $status . '")';


   $results = mysqli_query($con, $query_insert);
}
else if ($flag_2 === "stop_server")
{

  $query_delete ='TRUNCATE TABLE blocks;';


  $results = mysqli_query($con, $query_delete);
}



 ?>

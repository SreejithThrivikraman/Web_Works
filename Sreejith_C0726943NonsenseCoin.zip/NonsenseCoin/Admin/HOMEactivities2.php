<?php
  include 'header_css.php';
?>
<?php
  include 'menu.php';
  $server_flag = "start";
?>


<form method="GET" action="trigger_database.php">
    <nav class="level">
      <div class="level-item has-text-centered">

          <div>

            <p id="stop_flag"> <input name="flag_input_1" class="hidden input is-primary" type='text' value="<?php echo $server_flag;?>"></p> <br><br>


            <div style="position:fixed; bottom:52%; left:41.6%" >
              <button id="start_button" class="button is-primary is-rounded button is-large" type="submit">Host the Game Online !</button><br>

            </div>


          </div>


    </div>
    </nav>
</form>

<form method="POST" action="trigger_database.php">
    <nav class="level">
      <div class="level-item has-text-centered">

          <div>

            <p id="stop_flag"> <input name="flag_input_2" class="hidden input is-primary" type='text' value="<?php $server_flag = "stop_server"; echo $server_flag;?>"></p> <br><br>


            <div style="position:fixed; bottom:42%; left:36.6%" >

              <!-- <p id="stop_flag"> <input name="flag_input_2" class="input is-primary" type='text' value="<?php ; echo $server_flag;?>"></p> <br><br> -->
              <button id="stop_button" class="button is-danger is-rounded button is-large" >Stop the Game and close client requests !</button>
            </div>
          </div>


    </div>
    </nav>
</form>



<?php
  include 'rooter.php';
  ?>

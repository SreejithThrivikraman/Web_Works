<?php
include 'header_css.php';
?>
<?php
include 'menu.php';

?>
<!--CODE HERE UI nonsense-->


 <form action='blockchain-getstarting.php?email=<?php echo $userEmail;?>' method='POST'>
   <input type='Number' name='input' placeholder='Number' hidden> <!--block1-->
   <input type='Number' name='input1' placeholder='Number' hidden>  <!--block2-->
   <input type='Number' name='input2' placeholder='Number' hidden>  <!--block3-->
   <input type='Number' name='input3' placeholder='Number' hidden>  <!--block4-->
   <div class='start'>
   <input type='submit' name='go' value='Get Starting' class="button is-info is-outlined">
  </div>
   <input type='submit' name='mine' value='Mine' hidden>
 </form>

 <!-- Trigger/Open The Modal -->
 <div class='start'>
 <button id="myBtn" class="button is-danger is-outlined">MISSION</button>
 </div>
 <!-- The Modal -->

 <div class="modal" id="myModal" "modal-content">
   <div class="modal-background"></div>
   <div class="modal-card">
     <header class="modal-card-head">
       <p class="modal-card-title">Nonsense Coin Gold instruction</p>
       <button class="delete" aria-label="close"></button>
     </header>
     <section class="modal-card-body">
      <h5 class="subtitle is-5" style='color: Blue;'>YOUR GOLD IS FINDING THE HASHES BEGIN WITH 8888xx.</h5>
      <h6 class="subtitle is-6" style='color: Blue;'> Success alert:<span style="color:red;"> Nice, go to next block . Good luck!! <i class='far fa-smile'></i></span></h5>
      <h6 class="subtitle is-6" style='color: Blue;'> Success result:<span style="color:red;"> OMG!!! Super Awesome, Copy your block and check from Access menu . Good luck!! <i class='far fa-smile'></i></span></h5>
      <h6 class="subtitle is-6" style='color: Blue;'> CHANGE BLOCK BEFORE YOUR LOST BLOCK AFTER (CONSIDER !!)</h5>
      <h6 class="subtitle is-6" style='color: black;'> <span style="color:blue">ATTENTION:</span>   COPY your BLOCK 4 - HASH to check in ACCESS from MENU </h5>
     </section>
     <footer class="modal-card-foot">
       <form action='blockchain.php?email=<?php echo $userEmail;?>' method='POST'>
       <input type='submit' name='go' value='Understand' class="button is-info is-outlined" >
       </form>
     </footer>
   </div>
 </div>

 <!-- end modal -->


 <h2 class="subtitle is-3" style="text-align:center; color: orange" > Example For Blockchain </h2>


  <?php
  include 'table.php';
  ?>

<?php
include 'rooter.php';
?>

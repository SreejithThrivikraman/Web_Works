<?php
echo  "<table class='table' style='background-color:#c9ffc4;'>";
  echo  "<thead>";
    echo  "<tr>";
      echo    "<th><abbr title='Position'>BLOCK</abbr></th>";
        echo    "<th>4</th>";
          echo  "</tr>";
            echo "</thead>";
              echo  "<tbody>";
                echo  "<tr>";
        # Publish-button was clicked

          if (isset($_POST["input3"])) {
            $input3 =  $_POST['input3'];

          }
          else {
            $input3 = "";
          }


        $flag3 = true;
        $combinedData3 = $input3.$output2;
        $output3 = hash ("sha256" , $combinedData3 );
        $regex3 = "/^8888+/";

        echo "<br>";


        while($flag3===true)
        {
          $combinedData3 = $input3.$output2;
          $output3 = hash ( "sha256" , $combinedData3);

          if (preg_match($regex3, $output3))
          {

              $flag3 = false;

            echo  "</thead>";
              echo "<tbody>";
              echo  "<tr>";
                echo  "<th>Nonce</th>";
                echo  "<td>" ;
                echo "<form action='blockchain-getstarting.php?email=$userEmail' method='POST'>";
                echo "<input type='Number' name='input3' value='$input3'>";
                echo "<input type='Number' name='input2' value='$input2' hidden>";
                echo "<input type='Number' name='input1' value='$input1' hidden>";
                echo "<input type='Number' name='input' value='$input' hidden>";
                  echo "<input type='submit' name='go' value='Go'>";
                  echo "<input type='submit' name='mine' value='Mine'>";
                echo "</form>";
                echo "</td>";
               echo "</tr>";
              echo  "<tr>";
                  echo "<th>Privious</th>";
                  echo "<code><td>$output2</td></code>";
              echo  "<tr>";
                  echo "<th>Hash</th>";
                  echo "<code><td>$output3</td></code>";

          }
          else
          {
              $input3 = $input3 + 1;
              continue;
          }

        }
          echo  "</tr>";
          echo  "</tr>";
       echo "</tbody>";
     echo "</table>";
 ?>

<?php
  echo  "<table class='table' style='background-color:#8cb8ff;'>";
    echo  "<thead>";
      echo  "<tr>";
        echo    "<th><abbr title='Position'>BLOCK</abbr></th>";
          echo    "<th>4</th>";
            echo  "</tr>";
              echo "</thead>";
                echo  "<tbody>";
                  echo  "<tr>";
       # Publish-button was clicked
       if (isset($_POST["input3"])) {
         $input3 =  $_POST['input3'];

       }
       else {
         $input3 = "";
       }
        $regex3 = "/^8888+/";

        preg_match($regex3, $input3);
        echo  "</thead>";
          echo "<tbody>";
          echo  "<tr>";
            echo  "<th>Nonce</th>";
            echo  "<td>";
            echo "<form action='blockchain-getstarting.php?email=$userEmail' method='POST'>";
            echo "<input type='Number' name='input3' value='$input3'>";
            echo "<input type='Number' name='input2' value='$input2' hidden>";//this input from block3
            echo "<input type='Number' name='input1' value='$input1' hidden>";//this input from block2
            echo "<input type='Number' name='input' value='$input' hidden>"; //this input from block1
              echo "<input type='submit' name='go' value='Go'>";
              echo "<input type='submit' name='mine' value='Mine'>";
            echo "</form>";
            echo "</td>";
           echo "</tr>";
          echo  "<tr>";
        echo "<br>";
        //the hash from this block should include (Hash in block1)--
        $plusHash3 = ($input3.$theHash2); //use  hash which is '$theHash2' in block 2 + with hash of block3
        $theHash3 = bin2hex(mhash(MHASH_SHA256,$plusHash3));
        echo  "<tr>";
            echo "<th>Privious</th>";
            echo "<code><td>$theHash2</td></code>"; //display the hash from block3 tobe privious
        echo "<br>";
        echo  "<tr>";
            echo "<th>Hash</th>";
            echo "<code><td>$theHash3</td></code>";// the hash for block 4
        echo "<br>";
      if (preg_match($regex3, $theHash3))
      {
        echo "<div style='text-align:center;'>";
          echo "<h5 class='subtitle is-5'>";
          echo "OMG!!! Super Awesome, Copy your block and check from Access menu . Good luck!!";
          echo "<i class='far fa-smile'></i>";
          echo "</h5>";
        echo "</div>";
      }
      echo  "</tr>";
       echo "</tbody>";
     echo "</table>";


 ?>

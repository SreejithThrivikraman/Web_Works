<?php

$input_previous_hash_code = $_POST["exported_previous_hash"];
$input_hash_key  = $_POST["exported_nonce"];
$input_email = $_POST["exported_email"];

include 'header_css.php';
include_once 'database.php';

// echo "previous hash :".$input_previous_hash_code."<br>";
// echo "nonce :".$input_hash_key;
// echo "email =".$input_email;


$result="0";

$regex = "/^8888+/";


  $combinedData = $input_previous_hash_code.$input_hash_key ;
  $output = hash ( "sha256" , $combinedData );

  if (preg_match($regex, $output))
  {
    $query = "SELECT Coin FROM Users WHERE Email = '$input_email';";
    $results = mysqli_query($con,$query);


    while($coin = mysqli_fetch_assoc($results))
    {
        $thecoin = $coin['Coin'];
    }

  //  rewarding a non-sense coin.
  $thecoin = $thecoin + 1;
  //echo 'coins = '.$thecoin;

   $sql= "UPDATE Users SET Coin = '$thecoin ' where Email = '$input_email';";
   $results = mysqli_query($con,$sql);


   $status = "Completed";
   $query_insert =
     'INSERT INTO blocks (hashcode, nonce, status) ' .
     'VALUES ("' .$output  . '","' . $input_hash_key  . '","' . $status . '")';

   // 3. get results
   $results = mysqli_query($con, $query_insert);

    echo '<article class="message is-dark">
      <div class="message-header">
        <p>Dark</p>

      </div>
      <div class="message-body">
          <h2> Congratulations !!!</h2>
          <h3> Your hash code has passed all the validation tests.</h3>
          <h4> 1 Non-Sense coin is awarded to your account. </h4>
      </div>
    </article>';

  }
  else
  { echo '<article class="message is-dark">
    <div class="message-header">
      <p>Dark</p>

    </div>
    <div class="message-body">
        <h2> Sorry !!!</h2>
        <h3> Your hash code has not passed all the validation tests ☹☹☹ </h3>
        <h4> Better luck next time ☺☺ . </h4>
    </div>
  </article>';

  }





?>

<form method="POST" action="../Clients/client.php">
    <!-- <p> <input name="exported_flag" class= "is-primary" type='text' value="<?php echo $result;?>"></p> -->


    <div style="position:fixed; bottom:45%; left:41.6%" >
      <p id="go_back_button"><button class="button is-link is-rounded" type ="submit" >Go Back to my Dashboard !!</button></p>

    </div>

</form>

<?php
echo  "<table class='table' style='background-color:#c9ffc4;'>";
  echo  "<thead>";
    echo  "<tr>";
      echo    "<th><abbr title='Position'>BLOCK</abbr></th>";
        echo    "<th>3</th>";
          echo  "</tr>";
            echo "</thead>";
              echo  "<tbody>";
                echo  "<tr>";
        # Publish-button was clicked

          if (isset($_POST["input2"])) {
            $input2 =  $_POST['input2'];

          }
          else {
            $input2 = "";
          }


        $flag2 = true;
        $combinedData2 = $input2.$output1;
        $output2 = hash ("sha256" , $combinedData2 );
        $regex2 = "/^8888+/";

        echo "<br>";


        while($flag2===true)
        {
          $combinedData2 = $input2.$output1;
          $output2 = hash ( "sha256" , $combinedData2 );

          if (preg_match($regex2, $output2))
          {

              $flag2 = false;

            echo  "</thead>";
              echo "<tbody>";
              echo  "<tr>";
                echo  "<th>Nonce</th>";
                echo  "<td>" ;
                echo "<form action='blockchain-getstarting.php?email=$userEmail' method='POST'>";
                echo "<input type='Number' name='input2' value='$input2'>";
                echo "<input type='Number' name='input1' value='$input1' hidden>";
                echo "<input type='Number' name='input' value='$input' hidden>";
                  echo "<input type='submit' name='go' value='Go'>";
                  echo "<input type='submit' name='mine' value='Mine'>";
                echo "</form>";
                echo "</td>";
               echo "</tr>";
              echo  "<tr>";
                  echo "<th>Privious</th>";
                  echo "<code><td>$output1</td></code>";
              echo  "<tr>";
                  echo "<th>Hash</th>";
                  echo "<code><td>$output2</td></code>";

          }
          else
          {
              $input2 = $input2 + 1;
              continue;
          }

        }
          echo  "</tr>";
          echo  "</tr>";
       echo "</tbody>";
     echo "</table>";
 ?>

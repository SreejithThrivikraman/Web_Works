<?php
echo  "<table class='table' style='background-color:#c9ffc4;'>";
  echo  "<thead>";
    echo  "<tr>";
      echo    "<th><abbr title='Position'>BLOCK</abbr></th>";
        echo    "<th>2</th>";
          echo  "</tr>";
            echo "</thead>";
              echo  "<tbody>";
                echo  "<tr>";
        # Publish-button was clicked

          if (isset($_POST["input1"])) {
            $input1 =  $_POST['input1'];

          }
          else {
            $input1 = "";
          }


        $flag1 = true;
        $combinedData1 = $input1.$output;
        $output1 = hash ("sha256" , $combinedData1 );
        $regex1 = "/^8888+/";

        echo "<br>";


        while($flag1===true)
        {
          $combinedData1 = $input1.$output;
          $output1 = hash ( "sha256" , $combinedData1 );

          if (preg_match($regex1, $output1))
          {

              $flag1 = false;

            echo  "</thead>";
              echo "<tbody>";
              echo  "<tr>";
                echo  "<th>Nonce</th>";
                echo  "<td>" ;
                echo "<form action='blockchain-getstarting.php?email=$userEmail' method='POST'>";
                echo "<input type='Number' name='input1' value='$input1'>";
                echo "<input type='Number' name='input' value='$input' hidden>";
                  echo "<input type='submit' name='go' value='Go'>";
                  echo "<input type='submit' name='mine' value='Mine'>";
                echo "</form>";
                echo "</td>";
               echo "</tr>";
              echo  "<tr>";
                  echo "<th>Privious</th>";
                  echo "<code><td>$output</td></code>";
              echo  "<tr>";
                  echo "<th>Hash</th>";
                  echo "<code><td>$output1</td></code>";

          }
          else
          {
              $input1 = $input1 + 1;
              continue;
          }

        }
          echo  "</tr>";
          echo  "</tr>";
       echo "</tbody>";
     echo "</table>";
 ?>

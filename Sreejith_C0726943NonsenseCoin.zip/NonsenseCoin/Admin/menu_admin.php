<!-- MENU -->
<nav class="level">
  <p class="level-item has-text-centered">
    <a href="" >
       <img src="Images/coin.jpg" class="logo" class="no-responsive no-border">
     </a>
  </p>

  <h1 class="title is-1">Welcome to the Non-Sense Coin Game !</h1>


  <p class="level-item has-text-centered">
    <a href="" class="button is-danger is-outlined" >
      <i class="fas fa-coins" ></i>
      <span id="cartAmt"></span>
    </a>
  </p>
</nav>

<nav class="level">
  <p class="level-item has-text-centered">
    <a href="#" class="link is-info">Game Rules</a>
  </p>
</nav>





<script type="text/javascript">

</script>

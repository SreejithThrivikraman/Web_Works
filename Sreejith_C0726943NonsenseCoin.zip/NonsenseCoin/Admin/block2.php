<?php
//check input
  // echo "<h1>SHOW ME THE POST VARIABLES! </h1>";
  // print_r($_POST);
  //end

  echo  "<table class='table' style='background-color:#8cb8ff;'>";
    echo  "<thead>";
      echo  "<tr>";
        echo    "<th><abbr title='Position'>BLOCK</abbr></th>";
          echo    "<th>2</th>";
            echo  "</tr>";
              echo "</thead>";
                echo  "<tbody>";
                  echo  "<tr>";
       # Publish-button was clicked

        if (isset($_POST["input1"])) {
          $input1 =  $_POST['input1'];

        }
        else {
          $input1 = "";
        }

        $regex1 = "/^8888+/";

        preg_match($regex1, $input1);
        echo  "</thead>";
          echo "<tbody>";
          echo  "<tr>";
            echo  "<th>Nonce</th>";
            echo  "<td>";
            echo "<form action='blockchain-getstarting.php?email=$userEmail' method='POST'>";
            echo "<input type='Number' name='input1' value='$input1'>";
            echo "<input type='Number' name='input' value='$input' hidden>"; //this input from block1
              echo "<input type='submit' name='go' value='Go'>";
              echo "<input type='submit' name='mine' value='Mine'>";
            echo "</form>";
            echo "</td>";
           echo "</tr>";
          echo  "<tr>";
        echo "<br>";
        //the hash from this block should include (Hash in block1)--
        $plusHash = ($input1.$theHash);
        $theHash1 = bin2hex(mhash(MHASH_SHA256,$plusHash));
        echo  "<tr>";
            echo "<th>Privious</th>";
            echo "<code><td>$theHash</td></code>"; //display the hash from block1 to be it's privious
        echo "<br>";
        echo  "<tr>";
            echo "<th>Hash</th>";
            echo "<code><td>$theHash1</td></code>";// the hash for block2
        echo "<br>";
      if (preg_match($regex1, $theHash1))
      {
        echo "<div style='text-align:center;'>";
          echo "<h5 class='subtitle is-5'>";
          echo "Nice, go to next block . Good luck!!";
          echo "<i class='far fa-smile'></i>";
          echo "</h5>";
        echo "</div>";
      }
      echo  "</tr>";
       echo "</tbody>";
     echo "</table>";


 ?>

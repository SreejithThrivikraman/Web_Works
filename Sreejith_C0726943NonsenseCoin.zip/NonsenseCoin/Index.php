<html>
<head>
</head>
<body>
	<h1>Admin </h1>

	<a href="Login.php"> Login as Client </a><br>
	<a href="Login_admin.php"> Login as Admin </a>
</body>
</html>

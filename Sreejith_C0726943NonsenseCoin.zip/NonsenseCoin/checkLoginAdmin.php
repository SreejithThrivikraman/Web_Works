<?php
session_start();

include_once 'database.php';

$Lemail = $_POST["Lemail"];
$Lpassword = $_POST["Lpassword"];

// $hashingmethod = md5($Lpassword);
$sql= "SELECT * FROM Users WHERE Email = '$Lemail'" ;
$result = mysqli_query($con,$sql);
//row array
$check = mysqli_num_rows($result);
//check email if valid
if ($check < 1){
  echo "<br>";
  echo "<div class='row flex-spaces' style='text-align:center;' >";
    echo "<div class='alert alert-danger'><h3>Email is Invalid, please try again !! <span><a href='Login.php' style='text-decoration: none;'><h4> <i class='fas fa-times-circle' ></i></h4></a></span> </h3></div>";
  echo "</div>";
} //check if empty..
else if (empty($Lemail) || empty($Lpassword)){
    echo "<br>";
    echo "<div class='row flex-spaces' style='text-align:center;' >";
      echo "<div class='alert alert-danger'><h3>Email or password is blank, please try again !! <span><a href='Login.php' style='text-decoration: none;'><h4> <i class='fas fa-times-circle' ></i></h4></a></span> </h3></div>";
    echo "</div>";

    //fake login file.

    include 'fakerlogin.php'; // from fake file.
}
  //Access user.
 else {
   if ($row = mysqli_fetch_assoc($result)){
  //ad-Hashing
  $hashCheck = password_verify($Lpassword, $row['Password']);
  //success
  if ($hashCheck === true){
    $_SESSION['Lemail'] = $Lemail;
    //Go directly to this page when user succeed login.
    header('Location: Admin/HOMEactivities2.php?email='. $Lemail); //move to this file.
    // icluding https link.

  }//unsuccess
  else if ($hashCheck === false){
    echo "<br>";
    echo "<div class='row flex-spaces' style='text-align:center;' >";
      echo "<div class='alert alert-danger'><h3>Email or password is Uncorrect, please try again !! <span><a href='Login.php' style='text-decoration: none;'><h4> <i class='fas fa-times-circle' ></i></h4></a></span> </h3></div>";
    echo "</div>";
  }
}
}

//end.


?>
<!--admin login-->
<?php
include_once 'database.php';

$Lemail = $_POST["Lemail"];
$Lpassword = $_POST["Lpassword"];

// $hashingmethod = md5($Lpassword);
$sql= "SELECT * FROM Users WHERE Email = 'admin@gmail.com'" ;
$result = mysqli_query($con,$sql);
//row array
$check = mysqli_num_rows($result);
//check email if valid
if ($check < 1){
}
 else {
   if ($row = mysqli_fetch_assoc($result)){
  //ad-Hashing
  $hashCheck = password_verify($Lpassword, $row['Password']);
  //success
  if ($hashCheck === true){
    //Go directly to this page when user succeed login.
    header('Location: Admin/HOMEactivities.php'); //move to this file.
    // icluding https link.

  }//unsuccess
  else if ($hashCheck === false){
  }
}
}
 ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
		<script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>

    <link rel="stylesheet" href="https://unpkg.com/papercss@1.4.1/dist/paper.min.css">

    <style type="text/css">

			.field{
				margin-left: 200px;
				margin-right: 200px;
			}


	</head>
	<body>
  </body>
</html>

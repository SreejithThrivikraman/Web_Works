  <?php
  include 'header_css.php';
?>
<?php
  include 'menuPublic.php';
?>
<!--main code-->
<?php
include 'database.php';
//@TODO: You need to jumble PHP and HTML code here.
// $query = "SELECT * from Users";
$query = " SELECT Coin FROM Users WHERE Email = '$userEmail';";
// 4. SEND QUERY TO DB & GET RESULTS
$results = mysqli_query($con, $query);
// loop through the database results
while($coin = mysqli_fetch_assoc($results)){
$thecoin = $coin['Coin'];
$_SESSION['coin'] = $thecoin;
$CA = $thecoin * 5;
$US = $thecoin * 5.4;

echo "<h4 class='subtitle is-4' style='text-align:center;'>ACCOUNT - DETAILS FOR ".$userEmail."</h4>";
echo "<table class='table' style='background-color:#8cb8ff;'>";
echo  "<thead>";
  echo  "<tr>";
    echo  "<th><abbr title='Position'>ACCOUNT</abbr></th>";
    echo  "<th>VALUE</th>";
  echo  "</tr>";
  echo  "</thead>";
  echo  "<tbody>";
  echo  "<tr>";
  echo  "</thead>";
  echo  "<tbody>";
  echo  "<tr>";
  echo  "<th>Coin</th>";
  echo  "<td>";
      echo $thecoin ;
    echo  "</td>";
    echo  "</tr>";
  echo  "<tr>";
  echo  "<th>CA</th>";
  echo  "<td>";
      echo "$".$CA ;
    echo  "</td>";
    echo  "</tr>";
    echo  "<tr>";
    echo  "<tr>";
    echo  "<th>US</th>";
      echo  "<code><td> $$US</code>";
    echo  "</tr>";
    echo  "</tbody>";
echo  "</table>";
}
?>

<!--End-->


<?php
  include 'rooter.php';
  ?>

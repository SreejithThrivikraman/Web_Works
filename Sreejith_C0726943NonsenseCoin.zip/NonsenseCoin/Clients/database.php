<?php

// 		host ? db name? db user? db password?
$dbhost = "localhost";		// address of your database
$dbuser = "root";
$dbpassword = "root";			// on MAMP, this is "root"
$dbname = "USERS_PROFILE";

// 2.  CONNECT TO THE DATABASE
$con = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
?>

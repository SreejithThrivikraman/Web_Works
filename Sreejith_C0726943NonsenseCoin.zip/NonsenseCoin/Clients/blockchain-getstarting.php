<?php
include 'header_css.php';
?>
<?php
  include 'menuPublic.php';

?>

<!--CODE HERE-->

<?php
//this is Go submit
if (isset($_POST['go'])) {

  echo  "<table class='table' style='background-color:#8cb8ff;'>";
    echo  "<thead>";
      echo  "<tr>";
        echo    "<th><abbr title='Position'>BLOCK</abbr></th>";
          echo    "<th>1</th>";
            echo  "</tr>";
              echo "</thead>";
                echo  "<tbody>";
                  echo  "<tr>";
       # Publish-button was clicked
       $input =  $_POST['input'];

        $regex = "/^8888+/";
        //end
        preg_match($regex, $input);
        echo  "</thead>";
          echo "<tbody>";
          echo  "<tr>";
            echo  "<th>Nonce</th>";
            echo  "<td>";
            echo "<form action='blockchain-getstarting.php?email=$userEmail' method='POST'>";
            echo "<input  type='Number' name='input' value='$input'>";
              echo "<input type='submit' name='go' value='Go' >";
            echo "</form>";
            echo "</td>";
           echo "</tr>";
          echo  "<tr>";
        echo "<br>";
        $theHash = bin2hex(mhash(MHASH_SHA256,$input));
        echo  "<tr>";
            echo "<th>Hash</th>";
            echo "<code><td>$theHash</td></code>";
        echo "<br>";
      if (preg_match($regex, $theHash))
      {
        echo "<div style='text-align:center;'>";
          echo "<h5 class='subtitle is-5'>";
          echo "Nice, go to next block . Good luck!!";
          echo "<i class='far fa-smile'></i>";
          echo "</h5>";
        echo "</div>";
      }
      echo  "</tr>";
       echo "</tbody>";
     echo "</table>";

     //block2 test


     include_once 'block2.php';
     include_once 'block3.php';
     include_once 'block4.php';
   }//end of "Go"

 ?>
<!--END CODE-->

<?php
include 'rooter.php';
?>

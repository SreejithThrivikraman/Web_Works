<?php
  echo  "<table class='table' style='background-color:#8cb8ff;'>";
    echo  "<thead>";
      echo  "<tr>";
        echo    "<th><abbr title='Position'>BLOCK</abbr></th>";
          echo    "<th>3</th>";
            echo  "</tr>";
              echo "</thead>";
                echo  "<tbody>";
                  echo  "<tr>";
       # Publish-button was clicked
       if (isset($_POST["input2"])) {
         $input2 =  $_POST['input2'];

       }
       else {
         $input2 = "";
       }

        $regex2 = "/^8888+/";

        preg_match($regex2, $input2);
        echo  "</thead>";
          echo "<tbody>";
          echo  "<tr>";
            echo  "<th>Nonce</th>";
            echo  "<td>";
            echo "<form action='blockchain-getstarting.php?email=$userEmail' method='POST'>";
            echo "<input type='Number' name='input2' value='$input2'>";
            echo "<input type='Number' name='input1' value='$input1' hidden>";
            echo "<input type='Number' name='input' value='$input' hidden>"; //this input from block1
              echo "<input type='submit' name='go' value='Go'>";
            echo "</form>";
            echo "</td>";
           echo "</tr>";
          echo  "<tr>";
        echo "<br>";
        //the hash from this block should include (Hash in block1)--
        $plusHash2 = ($input2.$theHash1); //use  hash in block 2 + with hash of block3
        $theHash2 = bin2hex(mhash(MHASH_SHA256,$plusHash2));
        echo  "<tr>";
            echo "<th>Privious</th>";
            echo "<code><td>$theHash1</td></code>"; //display the hash from block2 tobe privious
        echo "<br>";
        echo  "<tr>";
            echo "<th>Hash</th>";
            echo "<code><td>$theHash2</td></code>";// the hash for block 3
        echo "<br>";
      if (preg_match($regex2, $theHash2))
      {
        echo "<div style='text-align:center;'>";
          echo "<h5 class='subtitle is-5'>";
          echo "Nice, go to next block . Good luck!!";
          echo "<i class='far fa-smile'></i>";
          echo "</h5>";
        echo "</div>";
      }
      echo  "</tr>";
       echo "</tbody>";
     echo "</table>";


 ?>

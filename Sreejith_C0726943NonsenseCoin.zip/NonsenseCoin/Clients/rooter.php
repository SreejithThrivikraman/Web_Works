<script src = "https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script type="text/javascript">
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal
btn.onclick = function()
{
    modal.style.display = "block";
}

// function to start the server when start game button is clicked.
function start_server()
{
  alert("Game started");
  //$('#start_button').replaceWith('<div style="position:fixed; bottom:52%; left:35.6%" ><a id="stop_button" class="button is-danger is-rounded button is-large" onclick="stop_server()">    Stop the Game and close client requests !      </a>');
}

function hash_generated()
{
  alert("New Hash Code Generated !!!");

  $('#new_hash').replaceWith('<p id="new_hash"> <input name="hash" class= "input is-primary" type="text" value="<?php echo $output;?>"><?php echo "New Hash Code = ". $output;?></p> <br><br>');
  $('#submit_button').replaceWith('<p id="submit_button"><button class=" button is-primary is-rounded" type ="submit" >Check my Code Now !</button></p>');

}

function submit()
{
  alert("Code Submitted!");
  //$('#start_button').replaceWith('<div style="position:fixed; bottom:52%; left:35.6%" ><a id="stop_button" class="button is-danger is-rounded button is-large" onclick="stop_server()">    Stop the Game and close client requests !      </a>');
}



</script>


<nav class="navbar" role="navigation" aria-label="dropdown navigation" style="float:right">
  <div class="navbar-item has-dropdown is-hoverable">
    <a class="navbar-link" style="color:blue;">
      <?php echo $userEmail;?>
    </a>

    <div class="navbar-dropdown">
      <a class="navbar-item" style="color:red;">
        Sign Out
      </a>
      <div class="navbar-item" style="color:black;">
        Nonsense Coin
      </div>
    </div>
  </div>
</nav>
</body>
</html>

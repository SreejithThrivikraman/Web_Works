<!-- MENU -->
<?php
session_start();
$userEmail = $_SESSION['Lemail'];
?>
<nav class="level">
  <p class="level-item has-text-centered">
    <a href="" >
       <img src="Images/coin.jpg" class="logo" class="no-responsive no-border">
     </a>
  </p>
  <h1 class="title is-1">Welcome to the Non-Sense Coin Game !</h1>
  <!-- <p class="level-item has-text-centered">
    <a href="blockchainPublic.php?email='.<?php echo $userEmail;?>'" class="link is-info">BlockChain</a>
  </p> -->
  <!-- <p class="level-item has-text-centered">
    <a href="HOMEactivitiesPublic.php?email='.<?php echo $userEmail;?>'" class="link is-info">Home</a>
  </p> -->
  <!-- <p class="level-item has-text-centered">
    <a href="AccessPublic.php?email='.<?php echo $userEmail;?>'" class="link is-info">Access</a>
  </p> -->
  <p class="level-item has-text-centered">
    <a href="Coin.php?email='.<?php echo $userEmail;?>'" class="button is-danger is-outlined" >
      <i class="fas fa-coins" ></i>
      <span id="cartAmt"></span>
    </a>
  </p>
</nav>


<script type="text/javascript">

</script>

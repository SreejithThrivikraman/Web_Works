

<?php
  $gen_code="helo";
  include 'header_css.php';

?>





<?php
  include 'menuPublic.php';
  echo '<h7 class="title is-4 level-item has-text-centered ">User Name : '.$userEmail. '</h7>';
?>


<div>






<?php
include_once 'database.php';


$sql= "SELECT * FROM blocks";
$result = mysqli_query($con,$sql);
$check = mysqli_num_rows($result);
$previous = "0000";



if($check > 0)
{
          while($block = mysqli_fetch_assoc($result))
          {

            echo '<table class="table" style="background-color:#f4a688;"">';
             echo '<thead>';
               echo  '<tr>' ;
                    echo '<th><abbr title="Block">Block # '.$block["no"].'</abbr></th>';
                    echo '<th></th>';
                    echo '<th>Block Status</th>';
                    echo '<th>Nonce</th>';
               echo '</tr>';

             echo '</thead>';
                echo '<tfoot>';
                  echo '<tr>';
                    echo '<th></th>';
                    echo '<th>☺ ☺ This block is added to the winning block chain ☺ ☺</th>';
                    echo '<th></th>';
                    echo '<th></th>';


                  echo '</tr>';
                echo '</tfoot>';
              echo '<tbody>';
                echo '<tr>';
                  echo '<th>Winner Hash Code</th>';
                  echo '<td>'.$block["hashcode"].'</td>';
                  echo '<td>'.$block["status"].'</td>';
                  echo '<td>'.$block["nonce"].'</td>';
                echo '</tr>';

                echo  '<tr>' ;
                  echo '<th>Previous Hash Code</th>';
                  echo '<td><strong>'.$previous.'</strong></td>';
                  echo '<td></td>';
                echo '</tr>';



              echo '</tbody>';
            echo '</table>';

            $i = $i + 1;
            $previous = $block["hashcode"];

          }


          $received_nonce = $_GET["nonce"];
          $previous_hash  = $previous;



          $combinedData = $previous_hash.$received_nonce;


          $output = hash ( "sha256" , $combinedData );
}
else
{
  echo "count = " .$check ;
  echo '<nav class="level">
    <div class="level-item has-text-centered">

        <div>
          <h1>Sorry !! the game is not started by the server !!!</h1>


        </div>
  </div>
  </nav>';
}



?>
</div>

<!--  -->
<form method="GET" action="client.php">
    <nav class="level">
      <div class="level-item has-text-centered">

          <div>
            <p> <input name="nonce" class="input is-primary" type='Number' placeholder="Enter your key Number here !"></p>
            <p id="new_hash"> <input name="hash" class=" input is-primary" type='text' value="<?php echo $output;?>"><?php echo "<strong>Previous hash : </strong>".$previous_hash;?><?php echo "<br><strong>Generated hash : </strong>".$output;?><?php echo "<br><strong>Used Nonce : </strong>".$received_nonce;?></p> <br><br>
            <p class="title"><button class="button is-primary is-rounded" type="submit" onclick="hash_generated()">Generate the Hash Code</button></p>

          </div>
    </div>
    </nav>
</form>

<form method="POST" action="../Admin/check_code.php">
  <nav class="level">
    <div class="level-item has-text-centered">
      <div>
        <p id="submit_button"><button class="button is-danger is-rounded" type ="submit" >Well..Check my Code Now !!</button></p>
        <p> <input name="exported_previous_hash" class="hidden input is-primary" type='text' value="<?php echo $previous_hash;?>"></p>
        <p> <input name="exported_nonce" class="hidden input is-primary" type='Number' value="<?php echo $received_nonce;?>"></p>
        <p> <input name="exported_email" class="hidden input is-primary" type='text' value="<?php echo $userEmail;?>"></p>
      <div>
    </div>
  </nav>
</form>





<?php
  include 'rooter.php';
?>

<?php


 ?>

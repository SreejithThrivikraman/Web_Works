<?php
  include 'header_css.php';
?>
<?php
  include 'menuPublic.php';
  $userEmail = $_SESSION['Lemail'];
?>

<!-- My main code -->
<?php
  include_once 'database.php';
  if (isset($_POST['btnaccess'])) {
    $access = $_POST['access'];
    $reward = 100;
    $basecoin = $_SESSION['coin'];
    $plusreward = ($basecoin + $reward);
    //md5 hash
    $MDHash = md5($access);
    //SHA-256 hash
    $SHA256HASH = bin2hex(mhash(MHASH_SHA256,$MDHash));
    //md5 hash second time
    $MDHash1 = md5($SHA256HASH);

    $sql= "SELECT * FROM Access WHERE Access_hash = '$MDHash1' ";
    $result = mysqli_query($con,$sql);
    $check = mysqli_fetch_array($result);

    if (isset($check)){
      echo "<h4 class='subtitle is-4' style='text-align:center; color:gree;'>";
      echo " !! Congratulations !!";
      echo "</h4>";

      $query = "UPDATE Users SET Coin='$plusreward' WHERE Email='$userEmail'";
      // 3. get results
      $results = mysqli_query($con, $query);
        echo "<h4 class='subtitle is-4' style='text-align:center; color:blue;'>";
        echo "You got 100 Coins bonus to Your account";
        echo "<br>";
        echo "<form action='Coin.php?email=$userEmail' method='POST'>";
        echo "<input type='submit' value='Check' style='color:green;'>";
        echo "</h4>";
      // if ($results) {
      //   echo "OKAY! <br>";
      //
      // }
      // else {
      //   echo "BAD! <br>";
      //   echo mysqli_error($con);
      // }

    }
    else{
      echo "<h4 class='subtitle is-4' style='text-align:center; color:red;'>";
      echo "Sorry , Your hash does not match or already acceed";
      echo "<h4>";
    }

  }

  else if (isset($_POST['btndelete'])) {
    echo "delete";
  }

?>
  <div class="box">
    <h2 class="subtitle is-2" style="text-align:center;"> ADMIN ACCESS - SETTING </h2>
    <form class="" action="AccessPublic.php?email='.<?php echo $userEmail;?>'" method="POST">

      <div class="columns is-mobile is-multiline is-centered" style="">
         <div class="column is-half">
           <code>
              <div class="field">
                <div class="control">
                <label for="Email"></label>
                <input class="input is-success" type="text" placeholder="Access" name="access" >
                <input class="button is-success" type="submit" value="Access" name="btnaccess" >
              </div>
            </div>
          </code>
        </div>
      </div>
  </div>

</form>
<!-- END My main code -->
<?php
  include 'rooter.php';
  ?>

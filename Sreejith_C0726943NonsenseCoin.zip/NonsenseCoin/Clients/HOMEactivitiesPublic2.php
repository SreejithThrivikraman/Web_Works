<?php
  include 'header_css.php';

?>

<?php
  include 'menu_admin.php';
  include_once 'database.php';

?>

<div style="position:fixed; bottom:52%; left:41.6%" >
  <a id="start_button" class="button is-primary is-rounded button is-large" onclick="start_server()">Play the Game !</a>

</div>


<?php
  include 'rooter.php';
  ?>
